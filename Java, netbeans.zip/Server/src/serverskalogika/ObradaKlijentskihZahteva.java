/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverskalogika;

import domen.Angazovanje;
import domen.Predmet;
import domen.Profesor;
import domen.Korisnik;
import domen.OpstiDomenskiObjekat;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import logika.Kontroler;
import transfer.TransferniObjekat;

/**
 *
 * @author izido
 */
public class ObradaKlijentskihZahteva extends Thread {

    Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    public boolean prekid = false;
    private Korisnik korisnik;

    public ObradaKlijentskihZahteva(Socket socket) {
        this.socket = socket;
    }

    public void inicijalizujTokove() throws IOException {
        in = new ObjectInputStream(socket.getInputStream());
        out = new ObjectOutputStream(socket.getOutputStream());
    }

    public Korisnik getKorisnika() {
        return korisnik;
    }

    public void setKorisnika(Korisnik korisnik) {
        this.korisnik = korisnik;
    }

    @Override
    public void run() {
        try {

            inicijalizujTokove();

            while (!prekid) {
                TransferniObjekat to = (TransferniObjekat) in.readObject();
                switch (to.getOperacija()) {

                    case TransferniObjekat.ULOGUJ_SE:
                        Korisnik k = null;
                        try {
                            k = (Korisnik) to.getUlazniParametar();
                            k = Kontroler.getInstance().ulogujSe(k);
                            to.setPovratnaVrednost(k);

                        } catch (Exception ex) {
                            ex.printStackTrace();
                            to.setIzuzetak(ex);
                        }
                        out.writeObject(to);
                        setKorisnika(k);
                        break;

                    case TransferniObjekat.SACUVAJ_PROFESORA:
                        try {
                            Profesor p = (Profesor) to.getUlazniParametar();
                            Kontroler.getInstance().sacuvajProfesora(p);
                            to.setPovratnaVrednost("Uspesno unesen profesor.");
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            to.setIzuzetak(ex);
                        }
                        out.writeObject(to);

                        break;

                    case TransferniObjekat.VRATI_SVE_PROFESORE:
                        List<OpstiDomenskiObjekat> listaProfesora;
                        try {
                            if (to.getUlazniParametar() != null) {
                                Profesor p = (Profesor) to.getUlazniParametar();
                                listaProfesora = Kontroler.getInstance().vratiProfesorePretrage(p);//pretraga sa uslovom
                            } else {
                                listaProfesora = Kontroler.getInstance().vratiSveProfesore();
                            }
                            to.setPovratnaVrednost(listaProfesora);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            to.setIzuzetak(ex);
                        }
                        out.writeObject(to);
                        break;

                    case TransferniObjekat.IZMENI_PROFESORA:

                        try {
                            Profesor p = (Profesor) to.getUlazniParametar();
                            Kontroler.getInstance().izmeniProfesora(p);
                            to.setPovratnaVrednost("Uspesno izmenjen profesor.");
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            to.setIzuzetak(ex);
                        }
                        out.writeObject(to);
                        break;

                    case TransferniObjekat.SACUVAJ_PREDMET:
                        try {
                            Predmet p = (Predmet) to.getUlazniParametar();
                            Kontroler.getInstance().sacuvajPredmet(p);
                            to.setPovratnaVrednost("Uspesno unesen predmet.");
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            to.setIzuzetak(ex);
                        }
                        out.writeObject(to);

                        break;

                    case TransferniObjekat.VRATI_SVE_PREDMETE:
                        List<OpstiDomenskiObjekat> listaPredmeta;
                        try {
                            if (to.getUlazniParametar() != null) {
                                Predmet p = (Predmet) to.getUlazniParametar();
                                listaPredmeta = Kontroler.getInstance().vratiPredmetePretrage(p);//pretraga sa uslovom
                            } else {
                                listaPredmeta = Kontroler.getInstance().vratiSvePredmete();
                            }
                            to.setPovratnaVrednost(listaPredmeta);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            to.setIzuzetak(ex);
                        }
                        out.writeObject(to);
                        break;

                    case TransferniObjekat.OBRISI_PREDMET:
                        try {
                            Predmet p = (Predmet) to.getUlazniParametar();
                            Kontroler.getInstance().izbrisiPredmet(p);
                            to.setPovratnaVrednost("Uspesno obrisan predmet.");
                        } catch (Exception ex) {
                            System.out.println("Nije uspelo brisanje!");
                            ex.printStackTrace();
                            to.setIzuzetak(ex);
                            to.setPovratnaVrednost("Nije izbrisan predmet jer postoji u angazovanju.");

                        }
                        out.writeObject(to);
                        break;
                        
                    case TransferniObjekat.SACUVAJ_ANGAZOVANJE:
                        try {
                            Angazovanje angazovanje = (Angazovanje) to.getUlazniParametar();
                            Kontroler.getInstance().sacuvajAngazovanje(angazovanje);

                            to.setPovratnaVrednost("Uspesno uneseno angazovanje.");
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            to.setIzuzetak(ex);
                        }
                        out.writeObject(to);

                        break;
                    case TransferniObjekat.VRATI_ANGAZOVANJE:
                        List<OpstiDomenskiObjekat> listaAngazovanja;
                        try {
                            if (to.getUlazniParametar() != null) {
                                Angazovanje a = (Angazovanje) to.getUlazniParametar();
                                listaAngazovanja = Kontroler.getInstance().vratiSvaAngazovanjaPretrage(a);
                            } else {
                                listaAngazovanja = Kontroler.getInstance().vratiSvaAngazovanja();
                            }
                            to.setPovratnaVrednost(listaAngazovanja);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            to.setIzuzetak(ex);
                        }
                        out.writeObject(to);
                        break;
                        case TransferniObjekat.VRATI_SVE_SKOLSKE_GODINE:
                        List<OpstiDomenskiObjekat> listaSkolskeGodine;
                        try {
                            if (to.getUlazniParametar() != null) {
                                listaSkolskeGodine = null;
                            } else {
                                listaSkolskeGodine = Kontroler.getInstance().vratiSveSkolskeGodine();
                            }
                            to.setPovratnaVrednost(listaSkolskeGodine);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            to.setIzuzetak(ex);
                        }
                        out.writeObject(to);
                        break;
                        case TransferniObjekat.VRATI_SVE_TIPOVE_ANGAZOVANJA:
                        List<OpstiDomenskiObjekat> listaTipovaAngazovanja;
                        try {
                            if (to.getUlazniParametar() != null) {
                                listaTipovaAngazovanja = null;
                            } else {
                                listaTipovaAngazovanja = Kontroler.getInstance().vratiSvaTipovaAngazovanja();
                            }
                            to.setPovratnaVrednost(listaTipovaAngazovanja);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            to.setIzuzetak(ex);
                        }
                        out.writeObject(to);
                        break;

                }
            }
        } catch (IOException ex) {
            Logger.getLogger(ObradaKlijentskihZahteva.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ObradaKlijentskihZahteva.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
