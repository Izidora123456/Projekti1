/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverskalogika;

import nit.NitZaZatvaranje;
import forme.ServerskaForma;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import logika.Kontroler;

/**
 *
 * @author izido
 */
public class PokretanjeServera extends Thread {

    ServerskaForma sf;

    public PokretanjeServera(ServerskaForma sf) {
        this.sf = sf;
    }

    @Override
    public void run() {
        try {
            ServerSocket ss = new ServerSocket(9000);
            sf.serverPokrenut();
            System.out.println("Server je pokrenut!");

            NitZaZatvaranje nit = new NitZaZatvaranje(ss, this);
            nit.start();

            while (!isInterrupted()) {
                Socket s = ss.accept();
                System.out.println("Klijent se povezao!");
                ObradaKlijentskihZahteva okz = new ObradaKlijentskihZahteva(s);
                okz.start();
            }

        } catch (IOException ex) {
            sf.serverNijePokrenut();
            System.out.println("Server je zaustavljen!");
        }
    }
}
