/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nit;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JLabel;

/**
 *
 * @author izido
 */
public class NitSat extends Thread{
    
    JLabel labelaSat;
    SimpleDateFormat sdf;

    public NitSat(JLabel labelaSat) {
        this.labelaSat = labelaSat;
        sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
    }

    @Override
    public void run() {
        while (true) {            
            labelaSat.setText(sdf.format(new Date()));
        }
    }
    
    
    
}
