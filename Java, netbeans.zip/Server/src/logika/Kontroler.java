/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logika;

import domen.Angazovanje;
import domen.Predmet;
import domen.Profesor;
import domen.Korisnik;
import domen.OpstiDomenskiObjekat;
import domen.SkolskaGodina;
import domen.TipAngazovanja;
import serverskalogika.ObradaKlijentskihZahteva;
import java.util.ArrayList;
import java.util.List;
import logika.so.korisnik.UlogujSeSO;
import logika.so.profesor.UnosProfesoraSO;
import logika.so.profesor.IzmenaProfesoraSO;
import logika.so.profesor.VratiProfesoreSO;
import logika.so.profesor.VratiProfesoreUslovSO;
import logika.so.predmet.UnosPredmetaSO;
import logika.so.predmet.BrisanjePredmetaSO;
import logika.so.predmet.VratiPredmeteSO;
import logika.so.predmet.VratiPredmeteUslovSO;
import logika.so.angazovanje.SacuvajAngazovanjeSO;
import logika.so.angazovanje.VratiAngazovanjaSO;
import logika.so.angazovanje.VratiAngazovanjaUslovSO;
import logika.so.skolskaGodina.VratiSkolskaGodinaSO;
import logika.so.tipAngazovanja.VratiTipAngazovanjaSO;

/**
 *
 * @author izido
 */
public class Kontroler {

    private static Kontroler instance;
    private List<ObradaKlijentskihZahteva> korisnici;

    private Kontroler() {
        korisnici = new ArrayList<>();
    }

    public List<ObradaKlijentskihZahteva> getKorisnici() {
        return korisnici;
    }

    public void setKorisnici(List<ObradaKlijentskihZahteva> korisnici) {
        this.korisnici = korisnici;
    }

    public static Kontroler getInstance() {
        if (instance == null) {
            instance = new Kontroler();
        }
        return instance;
    }

    /*korisnik*/
    public Korisnik ulogujSe(Korisnik k) throws Exception {
        UlogujSeSO usSO = new UlogujSeSO();
        usSO.izvrsiOperaciju(k);
        return usSO.getKorisnik();
    }

    /*profesor*/
    public void sacuvajProfesora(Profesor prof) throws Exception {
        UnosProfesoraSO upSO = new UnosProfesoraSO();
        upSO.izvrsiOperaciju(prof);
    }

    public void izmeniProfesora(Profesor p) throws Exception {
        IzmenaProfesoraSO ipso = new IzmenaProfesoraSO();
        ipso.izvrsiOperaciju(p);
    }

    public List<OpstiDomenskiObjekat> vratiSveProfesore() throws Exception {
        VratiProfesoreSO vpso = new VratiProfesoreSO();
        vpso.izvrsiOperaciju(new Profesor());
        return vpso.getLista();
    }

    public List<OpstiDomenskiObjekat> vratiProfesorePretrage(Profesor p) throws Exception {
        String uslov = "";
        if (p.getProfesorID() != -1) {
            uslov += " profesorID='" + p.getProfesorID() + "' AND ";
        }
        if (p.getImePrezime() != null) {
            uslov += " imePrezime='" + p.getImePrezime() + "' AND ";
        }
        if (p.getTitula() != null) {
            uslov += " titula='" + p.getTitula() + "' AND ";
        }
        if (p.getDatumRodjenja() != null) {
            uslov += " datumRodjenja='" + p.getDatumRodjenja() + "' AND ";
        }
        if (uslov != "") {
            VratiProfesoreUslovSO vpuSO = new VratiProfesoreUslovSO();
            uslov = uslov.substring(0, uslov.length() - 4);
            vpuSO.setUslov(uslov);
            vpuSO.izvrsiOperaciju(new Profesor());
            return vpuSO.getLista();
        } else {
            VratiProfesoreSO vpSO = new VratiProfesoreSO();
            vpSO.izvrsiOperaciju(new Profesor());
            return vpSO.getLista();
        }
    }

    /*predmet*/
    public void sacuvajPredmet(Predmet predmet) throws Exception {
        UnosPredmetaSO upSO = new UnosPredmetaSO();
        upSO.izvrsiOperaciju(predmet);
    }

    public void izbrisiPredmet(Predmet p) throws Exception {
        BrisanjePredmetaSO bpSO = new BrisanjePredmetaSO();
        bpSO.izvrsiOperaciju(p);
    }

    public List<OpstiDomenskiObjekat> vratiSvePredmete() throws Exception {
        VratiPredmeteSO vpso = new VratiPredmeteSO();
        vpso.izvrsiOperaciju(new Predmet());
        return vpso.getLista();
    }

    public List<OpstiDomenskiObjekat> vratiPredmetePretrage(Predmet p) throws Exception {
        String uslov = "";
        if (p.getPredmetID() != -1) {
            uslov += " predmetID='" + p.getPredmetID() + "' AND ";
        }
        if (p.getNazivPredmeta() != null) {
            uslov += " nazivPredmeta='" + p.getNazivPredmeta() + "' AND ";
        }
        if (p.getOpis() != null) {
            uslov += " opis='" + p.getOpis() + "' AND ";
        }
        if (p.getSemestar() != -1) {
            uslov += " semestar='" + p.getSemestar() + "' AND ";
        }
        if (uslov != "") {
            VratiPredmeteUslovSO vpuSO = new VratiPredmeteUslovSO();
            uslov = uslov.substring(0, uslov.length() - 4);
            vpuSO.setUslov(uslov);
            vpuSO.izvrsiOperaciju(new Predmet());
            return vpuSO.getLista();
        } else {
            VratiPredmeteSO vpSO = new VratiPredmeteSO();
            vpSO.izvrsiOperaciju(new Predmet());
            return vpSO.getLista();
        }
    }

    /*angazovanje*/
    public void sacuvajAngazovanje(Angazovanje a) throws Exception {
        SacuvajAngazovanjeSO saso = new SacuvajAngazovanjeSO();
        saso.izvrsiOperaciju(a);
    }

    public List<OpstiDomenskiObjekat> vratiSvaAngazovanja() throws Exception {
        VratiAngazovanjaSO vaso = new VratiAngazovanjaSO();
        vaso.izvrsiOperaciju(new Angazovanje());
        return vaso.getLista();
    }

    /*skolska godina*/
    public List<OpstiDomenskiObjekat> vratiSveSkolskeGodine() throws Exception {
        VratiSkolskaGodinaSO vsgso = new VratiSkolskaGodinaSO();
        vsgso.izvrsiOperaciju(new SkolskaGodina());
        return vsgso.getLista();
    }

    /*tip angazovanja*/
    public List<OpstiDomenskiObjekat> vratiSvaTipovaAngazovanja() throws Exception {
        VratiTipAngazovanjaSO vtaso = new VratiTipAngazovanjaSO();
        vtaso.izvrsiOperaciju(new TipAngazovanja());
        return vtaso.getLista();
    }

    public List<OpstiDomenskiObjekat> vratiSvaAngazovanjaPretrage(Angazovanje a) throws Exception  {
       String uslov = "";
        if (a.getPredmet()!= null) {
            uslov += " predmetID='" + a.getPredmet().getPredmetID() + "' AND ";
        }
        if (a.getProfesor() != null) {
            uslov += " profesorID='" + a.getProfesor().getProfesorID() + "' AND ";
        }
        
        if (uslov != "") {
            VratiAngazovanjaUslovSO vaSO = new VratiAngazovanjaUslovSO();
            uslov = uslov.substring(0, uslov.length() - 4);
            vaSO.setUslov(uslov);
            vaSO.izvrsiOperaciju(new Angazovanje());
            return vaSO.getLista();
        } else {
            VratiAngazovanjaSO vaSO = new VratiAngazovanjaSO();
            vaSO.izvrsiOperaciju(new Angazovanje());
            return vaSO.getLista();
        } }

}
