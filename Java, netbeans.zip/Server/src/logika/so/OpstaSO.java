/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logika.so;
import db.DBBroker;

/**
 *
 * @author izido
 */
public abstract class OpstaSO {
    public final synchronized void izvrsiOperaciju(Object obj) throws Exception {
        try {
            DBBroker.getInstance().otvoriKonekciju();
            proveriPreduslov(obj);
            izvrsiKonkretnuOperaciju(obj);
            DBBroker.getInstance().commit();
        } catch (Exception e) {
            e.printStackTrace();
            DBBroker.getInstance().rollback();
            throw e;
        } finally {
            DBBroker.getInstance().zatvoriKonekciju();
        }
    }

    public abstract void proveriPreduslov(Object obj) throws Exception;

    public abstract void izvrsiKonkretnuOperaciju(Object obj) throws Exception;


}
