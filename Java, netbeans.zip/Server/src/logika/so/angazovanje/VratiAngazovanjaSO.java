/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logika.so.angazovanje;

import db.DBBroker;
import domen.Angazovanje;
import domen.Korisnik;
import domen.OpstiDomenskiObjekat;
import domen.Predmet;
import domen.Profesor;
import domen.SkolskaGodina;
import domen.TipAngazovanja;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import logika.so.OpstaSO;
import logika.so.korisnik.VratiSveKorisnikeSO;
import logika.so.predmet.VratiPredmeteSO;
import logika.so.profesor.VratiProfesoreSO;
import logika.so.skolskaGodina.VratiSkolskaGodinaSO;
import logika.so.tipAngazovanja.VratiTipAngazovanjaSO;

/**
 *
 * @author izido
 */
public class VratiAngazovanjaSO extends OpstaSO {
    private List<OpstiDomenskiObjekat> lista = new ArrayList<>();
    private List<OpstiDomenskiObjekat> listaProfesora;
    private List<OpstiDomenskiObjekat> listaPredmeta;
    private List<OpstiDomenskiObjekat> listaSkolskaGodina;
    private List<OpstiDomenskiObjekat> listaTipAngazovanja;
    private List<OpstiDomenskiObjekat> listaKorisnika;

    public List<OpstiDomenskiObjekat> getLista() {
        return lista;
    }

    public void setLista(List<OpstiDomenskiObjekat> lista) {
        this.lista = lista;
    }
    
    @Override
    public void proveriPreduslov(Object obj) throws Exception {
    }

    @Override
    public void izvrsiKonkretnuOperaciju(Object obj) throws Exception {
        VratiProfesoreSO vprSO = new VratiProfesoreSO();
        vprSO.izvrsiKonkretnuOperaciju(new Profesor());
        listaProfesora = vprSO.getLista();
        
        VratiPredmeteSO vpreso = new VratiPredmeteSO();
        vpreso.izvrsiKonkretnuOperaciju(new Predmet());
        listaPredmeta = vpreso.getLista();
        
        VratiSkolskaGodinaSO vsgso = new VratiSkolskaGodinaSO();
        vsgso.izvrsiKonkretnuOperaciju(new SkolskaGodina());
        listaSkolskaGodina = vsgso.getLista();
        
        VratiTipAngazovanjaSO vtaso = new VratiTipAngazovanjaSO();
        vtaso.izvrsiKonkretnuOperaciju(new TipAngazovanja());
        listaTipAngazovanja = vtaso.getLista();
        
        VratiSveKorisnikeSO vskso = new VratiSveKorisnikeSO();
        vskso.izvrsiKonkretnuOperaciju(new Korisnik());
        listaKorisnika = vskso.getLista();

        lista = DBBroker.getInstance().vratiSve((Angazovanje) obj);
        for (OpstiDomenskiObjekat opstiDomenskiObjekat : lista) {
            Angazovanje a = (Angazovanje) opstiDomenskiObjekat;
            for (OpstiDomenskiObjekat opstiDomenskiObjekat1 : listaProfesora) {
                Profesor pr = (Profesor) opstiDomenskiObjekat1;
                if (Objects.equals(a.getProfesor().getProfesorID(), pr.getProfesorID()))  {
                    a.setProfesor(pr);
                }
            }
            for (OpstiDomenskiObjekat opstiDomenskiObjekat2 : listaPredmeta) {
                Predmet p = (Predmet) opstiDomenskiObjekat2;
                if (Objects.equals(a.getPredmet().getPredmetID(), p.getPredmetID()))  {
                    a.setPredmet(p);
                }
            }
            for (OpstiDomenskiObjekat opstiDomenskiObjekat3 : listaSkolskaGodina) {
                SkolskaGodina sk = (SkolskaGodina) opstiDomenskiObjekat3;
                if (Objects.equals(a.getSkolskaGodina().getSkolskaGodinaID(), sk.getSkolskaGodinaID()))  {
                    a.setSkolskaGodina(sk);
                }
            }
            for (OpstiDomenskiObjekat opstiDomenskiObjekat4 : listaTipAngazovanja) {
                TipAngazovanja ta = (TipAngazovanja) opstiDomenskiObjekat4;
                if (Objects.equals(a.getTipAngazovanja().getTipAngazovanjaID(), ta.getTipAngazovanjaID()))  {
                    a.setTipAngazovanja(ta);
                }
            }
            for (OpstiDomenskiObjekat opstiDomenskiObjekat5 : listaKorisnika) {
                Korisnik k = (Korisnik) opstiDomenskiObjekat5;
                if (Objects.equals(a.getKorisnik().getKorisnikID(), k.getKorisnikID()))  {
                    a.setKorisnik(k);
                }
            }
        }
    }
}
