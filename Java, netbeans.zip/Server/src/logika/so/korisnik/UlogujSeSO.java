/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logika.so.korisnik;

import db.DBBroker;
import domen.Korisnik;
import domen.OpstiDomenskiObjekat;
import java.util.List;
import logika.so.OpstaSO;

/**
 *
 * @author izido
 */
public class UlogujSeSO extends OpstaSO{
    private Korisnik korisnik;
    
    public Korisnik getKorisnik() {
        return korisnik;
    }

    @Override
    public void proveriPreduslov(Object obj) throws Exception {
        
    }

    @Override
    public void izvrsiKonkretnuOperaciju(Object obj) throws Exception {
        korisnik = (Korisnik) obj;
        List<OpstiDomenskiObjekat> korisnici = DBBroker.getInstance().vratiSve( korisnik, "username='" + korisnik.getUsername() + "' AND password='" + korisnik.getPassword() + "'");
        if (korisnici.size() == 1) {
            korisnik = (Korisnik) korisnici.get(0);
        } else {
            throw new Exception("Nije pronadjen korisnik. Proverite parametre korisnickog imena i sifre.");
        }
    }
    
}
