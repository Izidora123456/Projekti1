/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logika.so.predmet;

import domen.OpstiDomenskiObjekat;
import domen.Profesor;
import domen.Predmet;
import db.DBBroker;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import logika.so.OpstaSO;
import logika.so.profesor.VratiProfesoreSO;

/**
 *
 * @author izido
 */
public class VratiPredmeteUslovSO extends OpstaSO{

    private String uslov;
    private List<OpstiDomenskiObjekat> lista = new ArrayList<>();
    private List<OpstiDomenskiObjekat> listaProfesora;

    public String getUslov() {
        return uslov;
    }

    public void setUslov(String uslov) {
        this.uslov = uslov;
    }

    public List<OpstiDomenskiObjekat> getLista() {
        return lista;
    }

    public void setLista(List<OpstiDomenskiObjekat> lista) {
        this.lista = lista;
    }
            
    @Override
    public void proveriPreduslov(Object obj) throws Exception {
        
    }

    @Override
    public void izvrsiKonkretnuOperaciju(Object obj) throws Exception {
        VratiProfesoreSO vpSO = new VratiProfesoreSO();
        vpSO.izvrsiKonkretnuOperaciju(new Profesor());
        listaProfesora = vpSO.getLista();
        
        lista = DBBroker.getInstance().vratiSve((Predmet)obj, uslov);
        for (OpstiDomenskiObjekat opstiDomenskiObjekat : lista) {
            Predmet p = (Predmet) opstiDomenskiObjekat;
            for (OpstiDomenskiObjekat opstiDomenskiObjekat1 : listaProfesora) {
                Profesor pr = (Profesor) opstiDomenskiObjekat1;
                if (Objects.equals(p.getGlavniProfesorNaPredmetu().getProfesorID(), pr.getProfesorID()))  {
                    p.setGlavniProfesorNaPredmetu(pr);
                }
            }
        }
        
    }
    
}
