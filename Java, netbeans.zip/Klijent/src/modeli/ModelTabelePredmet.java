/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeli;

import domen.OpstiDomenskiObjekat;
import domen.Predmet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author izido
 */
public class ModelTabelePredmet extends AbstractTableModel {
    List<Predmet> lista = new ArrayList<>();

    public ModelTabelePredmet() {
        lista = new ArrayList<>();
    }

    public ModelTabelePredmet(List<OpstiDomenskiObjekat> list) {
        for (OpstiDomenskiObjekat opstiDomenskiObjekat : list) {
            Predmet p = (Predmet) opstiDomenskiObjekat;
            lista.add(p);
        }
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Predmet p = lista.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return p.getPredmetID();
            case 1:
                return p.getNazivPredmeta();
            case 2:
                return p.getOpis();
            case 3:
                return p.getSemestar();
            case 4:
                return p.getGlavniProfesorNaPredmetu().getImePrezime();
            default:
                return "Greska!";
        }
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Predmet ID";
            case 1:
                return "Naziv predmeta";
            case 2:
                return "Opis";
            case 3:
                return "Semestar";
             case 4:
                return "Glavni profesor";
            default:
                return "Greska!";
        }
    }

    public void osvezi() {
        fireTableDataChanged();
    }

    public Predmet dajIzabraniPredmet(int red) {
        return lista.get(red);
    }

    public List<Predmet> getLista() {
        return lista;
    }

    public void setLista(List<Predmet> lista) {
        this.lista = lista;
        fireTableDataChanged();
    }
}
