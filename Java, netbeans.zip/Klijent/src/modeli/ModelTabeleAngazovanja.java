/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeli;

import domen.Angazovanje;
import domen.OpstiDomenskiObjekat;
import domen.Predmet;
import domen.Profesor;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author izido
 */
public class ModelTabeleAngazovanja extends AbstractTableModel {

    List<Angazovanje> lista= new ArrayList<>();

    public ModelTabeleAngazovanja() {
        lista = new ArrayList<>();
    }

    public ModelTabeleAngazovanja(List<OpstiDomenskiObjekat> lista) {
        for (OpstiDomenskiObjekat opstiDomenskiObjekat : lista) {
            Angazovanje a = (Angazovanje) opstiDomenskiObjekat;
            this.lista.add(a);
        }
    }
    

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Angazovanje a = lista.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return a.getPredmet().getNazivPredmeta();
            case 1:
                return a.getProfesor().getImePrezime();
            case 2:
                return a.getTipAngazovanja().getNazivTipAngazovanja();
            case 3:
                return a.getKorisnik().getIme() + " " + a.getKorisnik().getPrezime();
            case 4:
                return a.getDatumKreiranja();
                
            default:
                return "Greska!";
        }
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Predmet";
            case 1:
                return "Profesor";
            case 2:
                return "Tip angazovanja";
            case 3:
                return "Korisnik";
            case 4:
                return "Datum kreiranja";
            default:
                return "Greska!";
        }

    }

    public void obrisi(int red) {
        lista.remove(red);
        fireTableDataChanged();
    }

    public List<Angazovanje> getLista() {
        return lista;
    }

    public void setLista(List<Angazovanje> lista) {
        this.lista = lista;
        fireTableDataChanged();
    }

    public Angazovanje vratiAngazovanje(int red) {
        return lista.get(red);
    }

}
