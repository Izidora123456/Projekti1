/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logika;

import domen.OpstiDomenskiObjekat;
import domen.SkolskaGodina;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import komunikacija.Komunikacija;

/**
 *
 * @author izido
 */
public class SkolskaGodinaKontroler {
    
    public static void popuniCBSkolaskaGodina(JComboBox cbSkolaskaGodina) {
       try {
            List<OpstiDomenskiObjekat> lista = Komunikacija.getInstanca().vratiSkolskeGodine();
            for (OpstiDomenskiObjekat opstiDomenskiObjekat : lista) {
                SkolskaGodina sg = (SkolskaGodina) opstiDomenskiObjekat;
                cbSkolaskaGodina.addItem(sg);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Nije uspelo ucitavanje.", "Nije uspelo ucitavanje.", JOptionPane.ERROR_MESSAGE);
        }
    }
    
}
