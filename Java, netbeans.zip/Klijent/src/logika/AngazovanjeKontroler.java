/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logika;

import domen.Angazovanje;
import domen.Predmet;
import domen.Profesor;
import domen.SkolskaGodina;
import domen.TipAngazovanja;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author izido
 */
public class AngazovanjeKontroler {

    public static Angazovanje unesiAngazovanje(Profesor profesorA, Predmet predmetA, TipAngazovanja tipA, SkolskaGodina skolGodA) throws Exception {

        if (profesorA.equals("*")) {
            throw new Exception("Mora da se izabere profesor!");
        }

        if (predmetA.equals("*")) {
            throw new Exception("Mora da se izabere predmet!");
        }

        if (tipA.equals("*")) {
            throw new Exception("Mora da se izabere tip angazovanja!");
        }

        if (skolGodA.equals("*")) {
            throw new Exception("Mora da se izabere skolska godina!");
        }

        long time =System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String date = sdf.format(time);
        Angazovanje a = new Angazovanje(0, tipA, predmetA, profesorA, Kontroler.getInstance().getUlogovaniKorisnik(), skolGodA, date);
        return a;

    }

}
