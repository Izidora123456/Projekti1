/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logika;

import domen.OpstiDomenskiObjekat;
import domen.TipAngazovanja;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import komunikacija.Komunikacija;

/**
 *
 * @author izido
 */
public class TipAngazovanjaKontroler {

    public static void popuniCBTipAngazovanja(JComboBox cbTipAngazovanja) {
       try {
            List<OpstiDomenskiObjekat> lista = Komunikacija.getInstanca().vratiTipAngazovanja();
            for (OpstiDomenskiObjekat opstiDomenskiObjekat : lista) {
                TipAngazovanja ta = (TipAngazovanja) opstiDomenskiObjekat;
                cbTipAngazovanja.addItem(ta);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Nije uspelo ucitavanje.", "Nije uspelo ucitavanje.", JOptionPane.ERROR_MESSAGE);
        }
    }
}
    

