/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transfer;

import java.io.Serializable;

/**
 *
 * @author izido
 */
public class TransferniObjekat implements Serializable{
    public static final int VRATI_SVE_PROFESORE = 1;
    public static final int VRATI_SVE_PREDMETE = 2;
    public static final int VRATI_SVE_PROFESORE_PO_PREDMETU = 3;
    public static final int VRATI_SVA_ANGAZOVANJA_ZA_PREDMET = 4;
    public static final int SACUVAJ_PROFESORA = 5;
    public static final int SACUVAJ_PREDMET = 6;
    public static final int SACUVAJ_ANGAZOVANJE = 7;
    public static final int VRATI_ANGAZOVANJE = 8;
    public static final int ULOGUJ_SE = 9;
    public static final int IZMENI_PROFESORA = 10;
    public static final int OBRISI_PREDMET = 11;
    public static final int VRATI_SVE_SKOLSKE_GODINE = 12;
    public static final int VRATI_SVE_TIPOVE_ANGAZOVANJA = 13;
    
    
    private int operacija;
    private Object ulazniParametar;
    private Object povratnaVrednost;
    private Exception izuzetak;

    public TransferniObjekat() {
    }

    public TransferniObjekat(int operacija, Object ulazniParametar, Object povratnaVrednost, Exception izuzetak) {
        this.operacija = operacija;
        this.ulazniParametar = ulazniParametar;
        this.povratnaVrednost = povratnaVrednost;
        this.izuzetak = izuzetak;
    }

    public int getOperacija() {
        return operacija;
    }

    public void setOperacija(int operacija) {
        this.operacija = operacija;
    }

    public Object getUlazniParametar() {
        return ulazniParametar;
    }

    public void setUlazniParametar(Object ulazniParametar) {
        this.ulazniParametar = ulazniParametar;
    }

    public Object getPovratnaVrednost() {
        return povratnaVrednost;
    }

    public void setPovratnaVrednost(Object povratnaVrednost) {
        this.povratnaVrednost = povratnaVrednost;
    }

    public Exception getIzuzetak() {
        return izuzetak;
    }

    public void setIzuzetak(Exception izuzetak) {
        this.izuzetak = izuzetak;
    }
}
