/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author izido
 */
public class TipAngazovanja implements Serializable, OpstiDomenskiObjekat {

    private int tipAngazovanjaID;
    private String nazivTipAngazovanja;

    public TipAngazovanja() {
    }

    public TipAngazovanja(int tipAngazovanjaID, String nazivTipAngazovanja) {
        this.tipAngazovanjaID = tipAngazovanjaID;
        this.nazivTipAngazovanja = nazivTipAngazovanja;
    }

    public int getTipAngazovanjaID() {
        return tipAngazovanjaID;
    }

    public String getNazivTipAngazovanja() {
        return nazivTipAngazovanja;
    }

    public void setTipAngazovanjaID(int tipAngazovanjaID) {
        this.tipAngazovanjaID = tipAngazovanjaID;
    }

    public void setNazivTipAngazovanja(String nazivTipAngazovanja) {
        this.nazivTipAngazovanja = nazivTipAngazovanja;
    }

    @Override
    public String vratiNazivTabele() {
        return "tipangazovanja";
    }

    @Override
    public String vratiNaziveAtributa() {
        return " (nazivTipAngazovanja) ";
    }

    @Override
    public String vratiVrednostZaInsert() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String vratiAtributeIzmena() {
        return "";
    }

    @Override
    public String vratiUslovIzmene() {
        return "";
    }

    @Override
    public String vratiUslovPretrage() {
        return "";
    }

    @Override
    public String vratiNazivKolone() {
        return "";
    }

    @Override
    public List<OpstiDomenskiObjekat> napuni(ResultSet rs) throws Exception {
        List<OpstiDomenskiObjekat> listaTipAngazovanja = new ArrayList<>();
        while (rs.next()) {
            TipAngazovanja ta = new TipAngazovanja();
            ta.setTipAngazovanjaID(rs.getInt("tipAngazovanjaID"));
            ta.setNazivTipAngazovanja(rs.getString("nazivTipAngazovanja"));

            listaTipAngazovanja.add(ta);
        }
        return listaTipAngazovanja;
    }

    @Override
    public OpstiDomenskiObjekat napraviPrazan() {
        return new TipAngazovanja(0, "");
    }

    @Override
    public String toString() {
        return  nazivTipAngazovanja ;
    }

}
