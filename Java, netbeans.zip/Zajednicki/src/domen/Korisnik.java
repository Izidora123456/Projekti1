/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author izido
 */
public class Korisnik implements Serializable, OpstiDomenskiObjekat {

    private int korisnikID;
    private String ime;
    private String prezime;
    private String username;
    private String password;

    public Korisnik() {
    }

    public Korisnik(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Korisnik(String ime, String prezime, String username, String password) {
        this.ime = ime;
        this.prezime = prezime;
        this.username = username;
        this.password = password;
    }

    public Korisnik(int korisnikID, String ime, String prezime, String username, String password) {
        this.korisnikID = korisnikID;
        this.ime = ime;
        this.prezime = prezime;
        this.username = username;
        this.password = password;
    }

    public int getKorisnikID() {
        return korisnikID;
    }

    public void setKorisnikID(int korisnikID) {
        this.korisnikID = korisnikID;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String vratiNazivTabele() {
        return "korisnik";
    }

    @Override
    public String vratiNaziveAtributa() {
        return " (username,password,ime,prezime) ";
    }

    @Override
    public String vratiVrednostZaInsert() {
        return "'" + username + "', '" + password + "', '" + ime + "', '" + prezime + "'";
    }

    @Override
    public String vratiAtributeIzmena() {
        return "username='" + username + "', password='" + password + "', ime='" + ime + "', prezime='" + prezime + "'";
    }

    @Override
    public String vratiUslovIzmene() {
        return "";
    }

    @Override
    public List<OpstiDomenskiObjekat> napuni(ResultSet rs) throws Exception {
        List<OpstiDomenskiObjekat> listaKorisnik = new ArrayList<>();
        while (rs.next()) {
            Korisnik korisnik = new Korisnik();
            korisnik.setKorisnikID(rs.getInt("korisnikID"));
            korisnik.setIme(rs.getString("ime"));
            korisnik.setPrezime(rs.getString("prezime"));
            korisnik.setUsername(rs.getString("username"));
            korisnik.setPassword(rs.getString("password"));
            listaKorisnik.add(korisnik);
        }
        return listaKorisnik;
    }

    @Override
    public OpstiDomenskiObjekat napraviPrazan() {
        Korisnik korisnik = new Korisnik(0, "Nema", "Nema", "Nema", "Nema");
        return korisnik;
    }

    public String toString() {
        return ime + " " + prezime ;
    }

    @Override
    public String vratiUslovPretrage() {
        return "";
    }

    @Override
    public String vratiNazivKolone() {
        return "";
    }

}
