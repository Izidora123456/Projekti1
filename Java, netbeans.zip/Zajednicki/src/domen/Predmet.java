/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author izido
 */
public class Predmet implements Serializable, OpstiDomenskiObjekat{
    private int predmetID;
    private String nazivPredmeta;
    private String opis;
    private int semestar;
    private Profesor glavniProfesorNaPredmetu;

    public Predmet() {
    }

    public Predmet(int predmetID, String nazivPredmeta, String opis, int semestar, Profesor glavniProfesorNaPredmetu) {
        this.predmetID = predmetID;
        this.nazivPredmeta = nazivPredmeta;
        this.opis = opis;
        this.semestar = semestar;
        this.glavniProfesorNaPredmetu = glavniProfesorNaPredmetu;
    }

    public Profesor getGlavniProfesorNaPredmetu() {
        return glavniProfesorNaPredmetu;
    }

    public void setGlavniProfesorNaPredmetu(Profesor glavniProfesorNaPredmetu) {
        this.glavniProfesorNaPredmetu = glavniProfesorNaPredmetu;
    }

    public int getPredmetID() {
        return predmetID;
    }

    public void setPredmetID(int predmetID) {
        this.predmetID = predmetID;
    }

    public String getNazivPredmeta() {
        return nazivPredmeta;
    }

    public void setNazivPredmeta(String nazivPredmeta) {
        this.nazivPredmeta = nazivPredmeta;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public int getSemestar() {
        return semestar;
    }

    public void setSemestar(int semestar) {
        this.semestar = semestar;
    }

    @Override
    public String toString() {
        return nazivPredmeta;
    }

    @Override
    public String vratiNazivTabele() {
        return "predmet";
    }

    @Override
    public String vratiNaziveAtributa() {
        return " (nazivPredmeta, opis, semestar, glavniProfesorNaPredmetu) ";
     }

    @Override
    public String vratiVrednostZaInsert() {
         return " '"  +nazivPredmeta + "', '" +opis + "', '" + semestar+ "', '" + glavniProfesorNaPredmetu.getProfesorID()+ "'";
  
    }

    @Override
    public String vratiAtributeIzmena() {
        return " predmetID ='" + predmetID + "', naivPredmeta='" + nazivPredmeta + "', semestar='" + semestar + "', glavniProfesorNaPredmetu ='" + glavniProfesorNaPredmetu.getProfesorID() + "'";
     }

    @Override
    public String vratiUslovIzmene() {
        return " predmetID ='" + predmetID + "'";
    }

    @Override
    public String vratiUslovPretrage() {
        return "";
     }

    @Override
    public String vratiNazivKolone() {
        return "";
    }

    @Override
    public List<OpstiDomenskiObjekat> napuni(ResultSet rs) throws Exception {
      List<OpstiDomenskiObjekat> listaPredmeta = new ArrayList<>();
        while (rs.next()) {
            Predmet p = new Predmet();
            p.setPredmetID(rs.getInt("predmetID"));
            p.setNazivPredmeta(rs.getString("nazivPredmeta"));
            p.setOpis(rs.getString("opis"));
            p.setSemestar(rs.getInt("semestar"));

            Profesor pr = new Profesor();
            pr.setProfesorID(rs.getInt("glavniProfesorNaPredmetu"));

            p.setGlavniProfesorNaPredmetu(pr);
            listaPredmeta.add(p);
        }
        return listaPredmeta;
     }


    @Override
    public OpstiDomenskiObjekat napraviPrazan() {
        Profesor p = (Profesor) (new Profesor()).napraviPrazan();
        return new Predmet(0, "", "", 0, p);
        
    }

    
}
