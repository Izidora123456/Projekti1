/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author izido
 */
public class SkolskaGodina implements Serializable, OpstiDomenskiObjekat {

    private int skolskaGodinaID;
    private String nazivSkolskaGodina;

    public SkolskaGodina() {
    }

    public SkolskaGodina(int skolskaGodinaID, String nazivSkolskaGodina) {
        this.skolskaGodinaID = skolskaGodinaID;
        this.nazivSkolskaGodina = nazivSkolskaGodina;
    }

    public int getSkolskaGodinaID() {
        return skolskaGodinaID;
    }

    public String getNazivSkolskaGodina() {
        return nazivSkolskaGodina;
    }

    public void setSkolskaGodinaID(int skolskaGodinaID) {
        this.skolskaGodinaID = skolskaGodinaID;
    }

    public void setNazivSkolskaGodina(String nazivSkolskaGodina) {
        this.nazivSkolskaGodina = nazivSkolskaGodina;
    }

    @Override
    public String vratiNazivTabele() {
        return "skolskagodina";
    }

    @Override
    public String vratiNaziveAtributa() {
        return " (nazivSkolskeGodine) ";
    }

    @Override
    public String vratiVrednostZaInsert() {
        return "";
    }

    @Override
    public String vratiAtributeIzmena() {
        return "";
    }

    @Override
    public String vratiUslovIzmene() {
        return "";
    }

    @Override
    public String vratiUslovPretrage() {
        return "";
    }

    @Override
    public String vratiNazivKolone() {
        return "";
    }

    @Override
    public List<OpstiDomenskiObjekat> napuni(ResultSet rs) throws Exception {
        List<OpstiDomenskiObjekat> listaSkolskaGodina = new ArrayList<>();
        while (rs.next()) {
            SkolskaGodina sk = new SkolskaGodina();
            sk.setSkolskaGodinaID(rs.getInt("skolskaGodinaID"));
            sk.setNazivSkolskaGodina(rs.getString("nazivSkolskeGodine"));

            listaSkolskaGodina.add(sk);
        }
        return listaSkolskaGodina;
    }

    @Override
    public OpstiDomenskiObjekat napraviPrazan() {
        return new SkolskaGodina(0, "");
    }

    @Override
    public String toString() {
        return  nazivSkolskaGodina ;
    }

}
