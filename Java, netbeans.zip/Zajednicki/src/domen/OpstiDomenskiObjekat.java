/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.sql.ResultSet;
import java.util.List;

/**
 *
 * @author izido
 */
public interface OpstiDomenskiObjekat {
    public String vratiNazivTabele();
    public String vratiNaziveAtributa();
    public String vratiVrednostZaInsert();
    public String vratiAtributeIzmena();
    public String vratiUslovIzmene();
    public String vratiUslovPretrage();
    public String vratiNazivKolone();
    
    public List<OpstiDomenskiObjekat> napuni(ResultSet rs) throws Exception;
    public OpstiDomenskiObjekat napraviPrazan();
}
